package pl.edu.uj.ii.skwarczek.productlist

class ProductAdapter {
}