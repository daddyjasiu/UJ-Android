package pl.edu.uj.ii.skwarczek.productlist

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.content.Intent

class ShoppingScreen : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.shopping_screen)
    }

}